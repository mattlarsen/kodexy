<?php kodexy()->loadView('templates/header'); ?>

<h1>My Blog</h1>

<p style="font-style:italic;">Tag line...</p>

<?php if(count($posts)): ?>
<?php foreach($posts as $post): ?>
    <h2><?php echo $post['title']; ?></h2>
    <p><?php echo nl2br($post['body']); ?></p>
    
    <?php if(kodexy()->session->isLoggedIn()): ?>
    <p><a href="<?php echo BASE_URL.'posts/edit/'.$post['id']; ?>">Edit</a> | 
    <a href="<?php echo BASE_URL.'posts/delete/'.$post['id'].'/'.kodexy()->session->getCsrfToken(); ?>" onclick="return confirm('Are you sure you want to delete this post?');">Delete</a></p>
    <?php endif; ?>
    
    <p style="font-style:italic;font-size:small;">Posted by admin, <?php echo date('jS F Y', strtotime($post['posted'])); ?>.</p>
<?php endforeach; ?>
<?php else: ?>
<p>No posts to display.</p>
<?php endif; ?>

<p><?php 
kodexy()->loadView('system/pager', array(
    'page'       => $page,
    'perPage'    => 2,
    'numRows'    => $postCount,
    'url'        => BASE_URL.'index/{page}',
));
?></p>

<?php kodexy()->loadView('templates/footer'); ?>