<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title><?php echo kodexy()->getPageTitle(); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL.'assets/css/core.css'; ?>" />
    <?php echo kodexy()->getPageHead(); ?>
</head>
<body>

<?php if(kodexy()->session->isLoggedIn()): ?>
<p>
	<a href="<?php echo BASE_URL; ?>">home</a> |
	<a href="<?php echo BASE_URL; ?>posts/add">add post</a> |
	<a href="<?php echo BASE_URL; ?>user/logout">logout</a>
</p>
<?php else: ?>
<p>
	<a href="<?php echo BASE_URL; ?>">home</a> |
	<a href="<?php echo BASE_URL; ?>user/login">login</a>
</p>
<?php endif; ?>

<?php kodexy()->loadView('system/messages'); ?>