<?php Kodexy::loadView('templates/header'); ?>

<h1>Login</h1>

<form method="post">
	
	<?php 
	Kodexy::loadView('system/forms/csrf');
	Kodexy::loadView('system/forms/errors');
	?>
	
	<p>Username: admin</p>
	
	<p><label for="password">Password</label>: <br />
	<?php
	Kodexy::loadView('system/forms/password', array(
		'name'				=> 'password',
	));
	?>
	</p>
	
	<input type="submit" value="Login" />
	
</form>

<script type="text/javascript">
document.getElementById('edit-password').focus();
</script>

<?php Kodexy::loadView('templates/footer'); ?>