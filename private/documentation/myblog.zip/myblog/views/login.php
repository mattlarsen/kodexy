<?php kodexy()->loadView('templates/header'); ?>

<h1>Login</h1>

<form method="post">
    
    <?php 
    kodexy()->loadView('system/forms/csrf');
    kodexy()->loadView('system/forms/errors');
    ?>
    
    <p>Username: admin</p>
    
    <p><label for="password">Password</label>: <br />
    <?php
    kodexy()->loadView('system/forms/password', array(
        'name'                => 'password',
    ));
    ?>
    </p>
    
    <input type="submit" value="Login" />
    
</form>

<script type="text/javascript">
document.getElementById('edit-password').focus();
</script>

<?php kodexy()->loadView('templates/footer'); ?>