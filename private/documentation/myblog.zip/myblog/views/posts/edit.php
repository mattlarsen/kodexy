<?php Kodexy::loadView('templates/header'); ?>

<h1>Edit Post</h1>

<form method="post">
	<?php 
	Kodexy::loadView('system/forms/csrf');
	Kodexy::loadView('system/forms/errors');
	?>
	
	<input type="hidden" name="postId" value="<?php echo $post['id']; ?>" />
	
	<p><label for="title">Title</label><br />
	<?php
	Kodexy::loadView('system/forms/textField', array(
		'name'			=> 'title',
		'defaultValue'	=> $post['title'],
		'attributes'	=> array(
			'maxlength'	=> 128,
		),
	));
	?></p>
	
	<p><label for="body">Body</label><br />
	<?php
	Kodexy::loadView('system/forms/textarea', array(
		'name'			=> 'body',
		'defaultValue'	=> $post['body'],
		'attributes'	=> array(
			'cols'		=> 70,
			'rows'		=> 7,
		),
	));
	?></p>
	
	<p><input type="submit" value="Post" /></p>
</form>

<?php Kodexy::loadView('templates/footer'); ?>