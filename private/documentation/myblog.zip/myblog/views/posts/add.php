<?php kodexy()->loadView('templates/header'); ?>

<h1>Add Post</h1>

<form method="post">
    <?php 
    kodexy()->loadView('system/forms/csrf');
    kodexy()->loadView('system/forms/errors');
    ?>
    
    <p><label for="title">Title</label><br />
    <?php
    kodexy()->loadView('system/forms/textField', array(
        'name'            => 'title',
        'attributes'      => array(
            'maxlength'   => 128,
        ),
    ));
    ?></p>
    
    <p><label for="body">Body</label><br />
    <?php
    kodexy()->loadView('system/forms/textarea', array(
        'name'            => 'body',
        'attributes'      => array(
            'cols'        => 70,
            'rows'        => 7,
        ),
    ));
    ?></p>
    
    <p><input type="submit" value="Post" /></p>
</form>

<?php kodexy()->loadView('templates/footer'); ?>