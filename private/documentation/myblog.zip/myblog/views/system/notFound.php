<?php Kodexy::loadView('templates/header'); ?>

<h1>Page Not Found</h1>

<p>Sorry about that. Back to <a href="<?php echo BASE_URL; ?>">homepage &raquo;</a></p>

<?php Kodexy::loadView('templates/footer'); ?>