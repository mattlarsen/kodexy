<?php kodexy()->loadView('templates/header'); ?>

<h1>Page Not Found</h1>

<p>Sorry about that. Back to <a href="<?php echo BASE_URL; ?>">homepage &raquo;</a></p>

<?php kodexy()->loadView('templates/footer'); ?>