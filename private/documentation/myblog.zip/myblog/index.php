<?php

/*======================================
Kodexy Framework v0.8.1
Author: Matt Larsen
Web: perthcomputing.com/projects/kodexy
======================================*/

/**
 *	Kodexy bootstrap file.
 */

require('system/Kodexy.php');
Kodexy::bootstrap();