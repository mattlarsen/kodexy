<?php

/*======================================
Kodexy Framework v0.8.2
Author: Matt Larsen
Web: github.com/mattlarsen/kodexy
======================================*/

/**
 * Kodexy application entry point.
 */

require('system/bootstrap.php');