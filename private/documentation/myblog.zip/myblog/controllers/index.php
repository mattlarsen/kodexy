<?php

$page = (int)kodexy()->router->getParam(0);

$posts = kodexy()->database->getRows('SELECT * FROM posts ORDER BY posted DESC LIMIT ?, ?', array($page * 2, 2));
$postCount = kodexy()->database->getColumn('SELECT COUNT(*) FROM posts');

kodexy()->loadView('index', array(
    'page'             => $page,
    'posts'            => $posts,
    'postCount'        => $postCount,
));