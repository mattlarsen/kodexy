<?php

$page = (int)Router::getParam(0);

$posts = Database::getRows('SELECT * FROM posts ORDER BY posted DESC LIMIT ?, ?', array($page * 2, 2));
$postCount = Database::getColumn('SELECT COUNT(*) FROM posts');

Kodexy::loadView('index', array(
	'page'			=> $page,
	'posts'			=> $posts,
	'postCount'		=> $postCount,
));