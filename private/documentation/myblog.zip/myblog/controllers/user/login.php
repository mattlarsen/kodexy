<?php

if(count($_POST))
{
	//validate
	if($_POST['password'] != 'pass123')
	{
		FormHandler::addError('password', 'Invalid password.');
		
		//not shown here: check for brute force login attempts.
	}
	
	if(FormHandler::isErrors())
	{
		Kodexy::loadView('login'); //re-load form
	}
	else
	{
		//login
		Session::login();
		Kodexy::addMessage('Welcome admin.');
		Router::redirect('');
	}
}
else
{
	//login form
	Kodexy::loadView('login');
}