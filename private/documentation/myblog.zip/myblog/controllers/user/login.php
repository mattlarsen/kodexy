<?php

if(count($_POST))
{
    //validate
    if($_POST['password'] != 'pass123')
    {
        kodexy()->formHandler->addError('password', 'Invalid password.');
        
        //not shown here: check for brute force login attempts.
    }
    
    if(kodexy()->formHandler->isErrors())
    {
        kodexy()->loadView('login'); //re-load form
    }
    else
    {
        //login
        kodexy()->session->login();
        kodexy()->addMessage('Welcome admin.');
        kodexy()->router->redirect('');
    }
}
else
{
    //login form
    kodexy()->loadView('login');
}