<?php

//logout
Session::logout();
Kodexy::addMessage('Logged out.');
Router::redirect('');