<?php

//logout
kodexy()->session->logout();
kodexy()->addMessage('Logged out.');
kodexy()->router->redirect('');