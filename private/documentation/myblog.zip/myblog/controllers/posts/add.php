<?php

//page validate
UserPermissions::loginRequired();

if(count($_POST))
{
	//validate
	if($_POST['title'] == '')
	{
		FormHandler::addError('title', 'Title is required.');
	}
	if(strlen($_POST['title']) > 128)
	{
		FormHandler::addError('title', 'Title cannot exceed 128 characters.');
	}
	if($_POST['body'] == '')
	{
		FormHandler::addError('body', 'Body is required.');
	}
	
	if(FormHandler::isErrors())
	{
		Kodexy::loadView('posts/add'); //re-load form
	}
	else
	{
		//add post
		Database::execute('INSERT INTO posts (title, body, posted) VALUES (?, ?, ?)', array(
			$_POST['title'],
			$_POST['body'],
			date('Y-m-d H:i:s'),
		));
		
		Kodexy::addMessage('Post added.');
		Router::redirect('');
	}
}
else
{
	//add post form
	Kodexy::loadView('posts/add');
}