<?php

//page validate
UserPermissions::loginRequired();

if(count($_POST))
{
    //validate
    if($_POST['title'] == '')
    {
        kodexy()->formHandler->addError('title', 'Title is required.');
    }
    if(strlen($_POST['title']) > 128)
    {
        kodexy()->formHandler->addError('title', 'Title cannot exceed 128 characters.');
    }
    if($_POST['body'] == '')
    {
        kodexy()->formHandler->addError('body', 'Body is required.');
    }
    
    if(kodexy()->formHandler->isErrors())
    {
        kodexy()->loadView('posts/add'); //re-load form
    }
    else
    {
        //add post
        kodexy()->database->execute('INSERT INTO posts (title, body, posted) VALUES (?, ?, ?)', array(
            $_POST['title'],
            $_POST['body'],
            date('Y-m-d H:i:s'),
        ));
        
        kodexy()->addMessage('Post added.');
        kodexy()->router->redirect('');
    }
}
else
{
    //add post form
    kodexy()->loadView('posts/add');
}