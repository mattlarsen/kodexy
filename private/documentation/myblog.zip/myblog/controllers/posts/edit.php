<?php

//page validate
UserPermissions::loginRequired();

$postId = (int)Router::getParam(0, 0);
$post = Database::getRow('SELECT * FROM posts WHERE id = ?', array($postId));
if(!count($post))
{
	Kodexy::addErrorMessage('Could not find post.');
	Router::redirect('');
}

if(count($_POST))
{
	//validate
	if($_POST['title'] == '')
	{
		FormHandler::addError('title', 'Title is required.');
	}
	if(strlen($_POST['title']) > 128)
	{
		FormHandler::addError('title', 'Title cannot exceed 128 characters.');
	}
	if($_POST['body'] == '')
	{
		FormHandler::addError('body', 'Body is required.');
	}
	
	if(FormHandler::isErrors())
	{
		Kodexy::loadView('posts/edit', array( //re-load form
			'post'	=> $post,
		));
	}
	else
	{
		//update post
		Database::execute('UPDATE posts SET title = ?, body = ?, posted = ? WHERE id = ?', array(
			$_POST['title'],
			$_POST['body'],
			date('Y-m-d H:i:s'),
			$postId
		));
		
		Kodexy::addMessage('Post updated.');
		Router::redirect('');
	}
}
else
{
	//edit post form
	Kodexy::loadView('posts/edit', array(
		'post'	=> $post,
	));
}