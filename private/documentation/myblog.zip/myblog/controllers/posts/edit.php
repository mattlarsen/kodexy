<?php

//page validate
UserPermissions::loginRequired();

$postId = (int)kodexy()->router->getParam(0, 0);
$post = kodexy()->database->getRow('SELECT * FROM posts WHERE id = ?', array($postId));
if(!count($post))
{
    kodexy()->addErrorMessage('Could not find post.');
    kodexy()->router->redirect('');
}

if(count($_POST))
{
    //validate
    if($_POST['title'] == '')
    {
        kodexy()->formHandler->addError('title', 'Title is required.');
    }
    if(strlen($_POST['title']) > 128)
    {
        kodexy()->formHandler->addError('title', 'Title cannot exceed 128 characters.');
    }
    if($_POST['body'] == '')
    {
        kodexy()->formHandler->addError('body', 'Body is required.');
    }
    
    if(kodexy()->formHandler->isErrors())
    {
        kodexy()->loadView('posts/edit', array( //re-load form
            'post'    => $post,
        ));
    }
    else
    {
        //update post
        kodexy()->database->execute('UPDATE posts SET title = ?, body = ?, posted = ? WHERE id = ?', array(
            $_POST['title'],
            $_POST['body'],
            date('Y-m-d H:i:s'),
            $postId
        ));
        
        kodexy()->addMessage('Post updated.');
        kodexy()->router->redirect('');
    }
}
else
{
    //edit post form
    kodexy()->loadView('posts/edit', array(
        'post'    => $post,
    ));
}