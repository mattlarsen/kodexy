<?php

//page validate
UserPermissions::loginRequired();
kodexy()->session->validateCsrfToken(kodexy()->router->getParam(1));

//delete post
$postId = (int)kodexy()->router->getParam(0, 0);
kodexy()->database->execute('DELETE FROM posts WHERE id = ?', array($postId));
kodexy()->addMessage('Post deleted.');
kodexy()->router->redirect('');