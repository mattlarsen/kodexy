<?php

//page validate
UserPermissions::loginRequired();
Session::validateCsrfToken(Router::getParam(1));

//delete post
$postId = (int)Router::getParam(0, 0);
Database::execute('DELETE FROM posts WHERE id = ?', array($postId));
Kodexy::addMessage('Post deleted.');
Router::redirect('');