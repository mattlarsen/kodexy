<?php

/*======================================
Kodexy Framework v0.8.1
Author: Matt Larsen
Web: perthcomputing.com/projects/kodexy
======================================*/

/**
 *	Application startup file: code that should be run for every request before the relevant controller is executed.
 */

//initialize Kodexy Session class.
Session::init();

Kodexy::loadCode('UserPermissions');