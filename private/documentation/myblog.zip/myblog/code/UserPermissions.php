<?php

class UserPermissions
{
    public static function loginRequired()
    {
        if(!kodexy()->session->isLoggedIn())
        {
            kodexy()->addErrorMessage('Access denied.');
            kodexy()->router->redirect('');
        }
    }
}