<?php

class UserPermissions
{
	public static function loginRequired()
	{
		if(!Session::isLoggedIn())
		{
			Kodexy::addErrorMessage('Access denied.');
			Router::redirect('');
		}
	}
}